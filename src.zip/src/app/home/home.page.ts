import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Headers } from '@angular/http';
import { RedditDataService } from '../provider/reddit-data.service';
import { PostPage } from '../post/post.page';
import { DatePipe } from '@angular/common';
import {json} from '@angular-devkit/core';
import {count, map} from 'rxjs/operators';
import { NgxPaginationModule } from 'ngx-pagination';
import 'rxjs/add/operator/map';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  users: any = []
  data: any = []
  date: any = []
    tvalue: any = {}
    hideButton = true;
    hidePagination = true;
    collection = [];
    p: any;
    search = "";
    postParams = {"id": ""};
  constructor(public navCtrl: NavController, public redditService: RedditDataService, public datepipe: DatePipe, public http: Http) {
         if (this.hidePagination) {
          this.hidePagination = false;
         }

    /*  this.http.get ( 'http://localhost/wordpress/wp-json/wp/v2/posts?_embed' )
          .pipe ( map ( res => res.json () ) ).subscribe ( data => {
          this.users = JSON.stringify ( data );
          this.data = JSON.parse ( this.users );

          console.log(this.data);
          this.data.date = new Date ();
          this.date = this.datepipe.transform ( this.data.date, 'MMM dd,yyyy' );
          this.tvalue = this.data.length;
          /!* this.navCtrl.navigateBack('');*!/
      } );*/
        this.http.get('http://localhost/wordpress/wp-json/my-route/my-phrase').map(res => res.json()).subscribe(data => {
          console.log(data);

          this.data = data;
          console.log(data[0].category_name);
      });


  }
   ionViewDidLoad() {
   // this.redditService.getRemoteData();
      const users = this.redditService.getRemoteData();
      this.users = users;
      console.log(this.users);
      this.users.date = new Date();
      this.date = this.datepipe.transform(this.users.date, 'MMM dd,yyyy');
       }

       getAllPost() {
        this.navCtrl.navigateForward('post');
       }

    getPostDetails(id: any) {

        this.postParams.id = id;

        console.log(this.postParams);
        this.http.post('http://localhost/wordpress/wp-json/custom/v1/get-post-by-category', JSON.stringify(this.postParams)).map( res => res.json()).subscribe( data => {
            this.data = data;
            localStorage.setItem('userData', JSON.stringify(this.data) )
            console.log(data);
            this.navCtrl.navigateForward('categorydetails');
        });

    }

       searchPost() {

      console.log(this.search);
            this.http.get('http://localhost/wordpress/wp-json/wp/v2/posts?search=' + this.search).map( res => res.json()).subscribe( data => {
                this.data = data;
                localStorage.setItem('userData', JSON.stringify(this.data) )
                console.log(data);
                this.navCtrl.navigateForward('search');
            });
    }

       }
